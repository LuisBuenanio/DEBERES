package net.osgg.restwebrecipes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestwebrecipesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestwebrecipesApplication.class, args);
	}

}
