package net.osgg.restwebrecipes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestwebrecipesApplicationTests {

	@Test
	void contextLoads() {
	}

}
