
INSERT INTO receta_table(nombre, foto, preparacion, dificultad) VALUES ('Tacos',  '7f5cdd28-c77b-4199-944f-ebe905e7ac61', 'blah blah', 'Moderado');
INSERT INTO receta_table(nombre, foto, preparacion, dificultad) VALUES ('Tortas', 'c4956332-20f7-41c2-9483-f194c4432515', 'blah blah', 'Fácil');
